package com.example.newsapp.mvvm

import android.app.Application

class NewsApplication () : Application()